//
//  DummyViewController.swift
//  NASDUBAI
//
//  Created by MobatiaMacMini5 on 04/11/23.
//

import UIKit

class DummyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

 
    @IBAction func notification(_ sender: Any) {
    }
    
    @IBAction func calendar(_ sender: Any) {
    }
    @IBAction func Communication(_ sender: Any) {
    }
    @IBAction func Absence(_ sender: Any) {
    }
    @IBAction func Payments(_ sender: Any) {
    }
    @IBAction func LunchBox(_ sender: Any) {
    }
    @IBAction func MusicAcademy(_ sender: Any) {
    }
    @IBAction func ParentsEssentials(_ sender: Any) {
    }
    @IBAction func EarlyYears(_ sender: Any) {
    }
    @IBAction func Primary(_ sender: Any) {
    }
    @IBAction func Secondary(_ sender: Any) {
    }
    @IBAction func SixthForm(_ sender: Any) {
    }
    @IBAction func University(_ sender: Any) {
    }
    @IBAction func Sports(_ sender: Any) {
    }
    @IBAction func PerformingArts(_ sender: Any) {
    }
    @IBAction func Enrichment(_ sender: Any) {
    }
    @IBAction func ParentAssociation(_ sender: Any) {
    }
    @IBAction func ParentsMeeting(_ sender: Any) {
    }
    @IBAction func NAEProgrames(_ sender: Any) {
    }
    @IBAction func Repors(_ sender: Any) {
    }
    @IBAction func PermissionForms(_ sender: Any) {
    }
    @IBAction func Gallery(_ sender: Any) {
    }
}
