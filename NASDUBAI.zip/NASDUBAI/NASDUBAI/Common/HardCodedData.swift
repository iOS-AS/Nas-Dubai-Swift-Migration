//
//  HardCodedData.swift
//  NASDUBAI
//
//  Created by MobatiaMacMini5 on 04/11/23.
//

import UIKit

struct HardCodedData{
    
    
}
